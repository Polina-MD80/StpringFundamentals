package softuni.spring.model.entity.enums;

public enum CategoryName {
    Coffee, Cake, Drink, Other;
}
